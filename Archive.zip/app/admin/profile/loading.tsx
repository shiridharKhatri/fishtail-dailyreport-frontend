import { ProfileSkeletonLoader } from "@/components/skeleton-loaders/profile-skeleton"

export default function Loading() {
  return <ProfileSkeletonLoader />
}
