import { DashboardSkeletonLoader } from "@/components/skeleton-loaders/dashboard-skeleton"

export default function Loading() {
  return <DashboardSkeletonLoader />
}
