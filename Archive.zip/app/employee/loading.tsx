import { EmployeeDashboardSkeletonLoader } from "@/components/skeleton-loaders/employee-dashboard-skeleton"

export default function Loading() {
  return <EmployeeDashboardSkeletonLoader />
}
